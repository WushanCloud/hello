#include <unistd.h>
#include <stdio.h>
//关于父子进程的调度没有先后顺序，全靠调度器来实现
int main()
{
  int i= 0;
  for(i = 0;i<2;i++)
  {
    printf("当前为%d\n",getpid());
    fflush(stdout);
    sleep(1);

    printf("fork前第%d次循环内\n",i+1);
    fflush(stdout);
    sleep(1);
    fork();

    printf("当前 %d\t",getpid());
    printf("当前父进程是 %d\t",getppid());
    printf("fork后第%d次循环内\n",i+1);
    fflush(stdout);
    sleep(1);

    printf("当前 %d 循环内\n",getpid());
    fflush(stdout);
    sleep(1);
  }
  printf("当前%d循环外\n",getpid());
  fflush(stdout);
  return 0;
}
