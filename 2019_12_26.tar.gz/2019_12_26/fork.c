#include <stdio.h>
#include <unistd.h>

int main()
{
  int i =10;
  pid_t p = fork();
  if(p < 0)
  {
    printf("error\n");
  }
  else if(p == 0)
  {
    printf("子进程\n");
    printf("%d\n",i);
  }
  else 
  {
    i = 100;
    printf("父进程\n");
    printf("%d",i);
  }
  return 0;
}
